using System;
class Program{
   public static void Main(){
        int width = (Console.WindowWidth)/2;
        int height = (Console.WindowHeight)/2;
        Console.SetWindowSize(width, height);//width, height
        Console.Write(">");
        String texto;
        bool entr = true;
        while(entr){
            texto = Console.ReadLine();
            if(texto=="exit"){
                entr = false;
            }
        }
        //Console.ReadKey();
        Console.WriteLine("exit");
    }
}

//C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe
//para compilar agrega esa ruta + Name.cs
/*#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
using namespace std;
HANDLE wHnd;

int main (){
    
    string nombre;
	cout<<">";
	getline(cin,nombre);
	//cout<<"------";
	//aqui vendria las condiciones si quieres guardar o no 
	cin.get();

    //size of console
    wHnd = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT windowSize = {0, 0, 30, 15};
    SetConsoleWindowInfo(wHnd, 1, &windowSize);
    return 0;
}*/